WP Blogger v1.1.0
=================

Must-Use WordPress activity and security logger.

Install:
1. Copy wp-content/mu-plugins/wp-blogger.php to the site's wp-content/mu-plugins/ directory.
2. Copy wp-content/wp-blogger/ to the site's wp-content/wp-blogger/ directory.
3. Create the preferred log directory on Linux:
   sudo mkdir -p /var/log/wp-blogger
   sudo chown root:www-data /var/log/wp-blogger
   sudo chmod 770 /var/log/wp-blogger

Primary log path: /var/log/wp-blogger/
Fallback log path: wp-content/uploads/wp-blogger/
Rotation: monthly JSONL files.

Admin UI:
WP Admin -> Blogger -> Activity
WP Admin -> Blogger -> Security Events

Security v1.1 additions:
- Periodic filesystem integrity scan through WP-Cron, approximately every 15 minutes when cron is triggered.
- Manual "Run Security Scan Now" control.
- First scan establishes a SHA-256 baseline.
- Detects tracked file additions, modifications and deletions.
- Critical monitoring for wp-config.php, .htaccess, wp-admin, wp-includes and MU plugins.
- High-priority monitoring for plugin/theme code changes.
- Detects executable/script files placed in wp-content/uploads.
- Flags common suspicious filenames such as shell.php, ws.php, wso.php, c99.php, r57.php and about.php.
- XML-RPC activity logging.
- REST users endpoint activity logging.
- Failed-login thresholds at 5, 10 and 20 failures from the same IP within a rolling 15-minute transient window.

Important:
The initial filesystem baseline records the current state. It does not establish that the current files are trustworthy. Create the baseline only after a known-clean recovery where possible.
WP-Cron is traffic-driven by default, so exact scan timing depends on site requests unless the server invokes wp-cron.php separately.
